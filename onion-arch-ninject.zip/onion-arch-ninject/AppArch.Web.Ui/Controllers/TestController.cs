﻿using AppArch.Domain.Interfaces;
using AppArch.Infrastructure.DependecyResolution;
using AppArch.Services.Interfaces;
using AppArch.Web.Ui.Services;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace AppArch.Web.Ui.Controllers
{
    public class TestController : Controller
    {
        private IKernel _ninjectKernel;


        public TestController()
        {

        }
        //
        // GET: /Test/

        public ActionResult Index()
        {
            double _different;
            DateTime a = DateTime.Now; 
            for (int i = 0; i < 100000; i++)
            {                         
                _ninjectKernel = new StandardKernel
               (
                   new LoggingModule(),
                   new ConfigModule(),
                   new RepositoryModule()
               );
                _ninjectKernel.Bind<IProductService>().To<ProductService>();
                                       }
            DateTime b = DateTime.Now;
            _different = (b - a).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine("Time of initialization Test controller :" + (b - a).TotalMilliseconds);
            return View(_different);
        }

    }
}
